<footer class="footer">
      <p>&copy; 2019 Designed By Varun Agarwal</p>
    </footer>
</div>
		</body>
</html>